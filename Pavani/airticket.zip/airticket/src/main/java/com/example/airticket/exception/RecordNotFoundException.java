package com.example.airticket.exception;

public class RecordNotFoundException extends RuntimeException{

        public RecordNotFoundException(String message)
        {
            super(message);
        }
    }


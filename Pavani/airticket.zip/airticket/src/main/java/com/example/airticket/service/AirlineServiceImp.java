package com.example.airticket.service;

import com.example.airticket.entity.Airline;

import java.util.List;

public interface AirlineServiceImp {
    List<Airline> getAirlinesDetails();
}

package com.example.airticket.service;

import com.example.airticket.entity.Location;

import java.util.List;

public interface LocationServiceImpl {
    List<Location> getLocationDetails();
}

package com.example.airticket.service;


public interface LoginServiceImp {

}

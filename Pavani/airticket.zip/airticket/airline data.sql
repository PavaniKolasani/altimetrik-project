use project;
insert into airline values(airline_id,"Indigo","2023-11-21");